# immo-alerts

Reçois chaque jour par email les nouvelles annonces immobilières
correspondant à tes critères — critères que tu modifies simplement en
éditant `config.yaml`, sans toucher au code.

## Comment ça marche

1. Une **GitHub Action** se lance automatiquement chaque jour (cron dans
   `.github/workflows/daily.yml`).
2. Elle lit `config.yaml` (tes critères + tes flux RSS).
3. Elle récupère les annonces des flux, filtre celles qui matchent tes
   critères et n'ont pas déjà été vues (`seen.json`).
4. Elle t'envoie un email récapitulatif s'il y a du nouveau.

## Installation

### 1. Récupère des flux RSS d'alertes immobilières

C'est l'étape la plus importante. La plupart des portails immobiliers
permettent de créer une **recherche sauvegardée** avec tes critères de
ville/prix, puis proposent une alerte par email ou un flux RSS.
Alternative : des services comme rss.app permettent de transformer une
page de résultats de recherche en flux RSS.

⚠️ Vérifie toujours les conditions d'utilisation du site avant d'automatiser
quoi que ce soit — ce script est prévu pour lire des flux RSS destinés à
cet usage, pas pour contourner des protections anti-bot.

### 2. Configure `config.yaml`

Ajoute tes flux et ajuste les critères :

```yaml
feeds:
  - name: "Lausanne T2/T3"
    url: "TON_URL_RSS_ICI"
    enabled: true
```

Tu peux modifier ce fichier **tous les jours** directement sur GitHub
(bouton crayon ✏️ sur le fichier) — pas besoin de coder.

### 3. Configure l'envoi d'email

Si tu utilises Gmail :
- Active la validation en 2 étapes sur ton compte Google
- Crée un "mot de passe d'application" : https://myaccount.google.com/apppasswords

Dans les **Settings > Secrets and variables > Actions** de ton repo GitHub,
ajoute ces secrets :

| Secret       | Exemple (Gmail)              |
|--------------|-------------------------------|
| `SMTP_HOST`  | `smtp.gmail.com`              |
| `SMTP_PORT`  | `587`                          |
| `SMTP_USER`  | `toi@gmail.com`                |
| `SMTP_PASS`  | (le mot de passe d'application)|

### 4. Active les Actions

Onglet **Actions** de ton repo → active les workflows si demandé.
Tu peux aussi lancer une exécution manuelle via "Run workflow" pour tester.

## Tester en local

```bash
pip install -r requirements.txt
export SMTP_HOST=smtp.gmail.com SMTP_PORT=587 SMTP_USER=toi@gmail.com SMTP_PASS=xxxx
python main.py
```

## Limites connues

- L'extraction de prix/surface depuis un flux RSS est approximative :
  le filtrage par mots-clés (`keywords_include`/`keywords_exclude`) est
  fiable, mais `budget_max`/`surface_min` ne sont pas encore appliqués
  automatiquement (le format du texte varie trop d'un site à l'autre).
  Si tu veux, je peux ajouter un parsing regex adapté au format exact
  de tes flux une fois que tu les auras.
- Le fuseau horaire du cron est UTC ; ajuste l'heure dans
  `daily.yml` si besoin.
