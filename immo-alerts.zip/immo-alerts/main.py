#!/usr/bin/env python3
"""
immo-alerts : lit des flux RSS d'annonces immobilières, filtre selon
config.yaml, et envoie un email récapitulatif quotidien des nouvelles
annonces correspondant aux critères.

Usage:
    python main.py

Variables d'environnement requises (voir README.md) :
    SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS
"""

import os
import json
import yaml
import feedparser
from pathlib import Path
from emailer import send_email

CONFIG_PATH = Path(__file__).parent / "config.yaml"
SEEN_PATH = Path(__file__).parent / "seen.json"


def load_config():
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def load_seen():
    if SEEN_PATH.exists():
        with open(SEEN_PATH, "r", encoding="utf-8") as f:
            return set(json.load(f))
    return set()


def save_seen(seen_ids):
    with open(SEEN_PATH, "w", encoding="utf-8") as f:
        json.dump(sorted(seen_ids), f, ensure_ascii=False, indent=2)


def matches_criteria(entry, criteria):
    text = f"{entry.get('title', '')} {entry.get('summary', '')}".lower()

    for kw in criteria.get("keywords_exclude", []) or []:
        if kw.lower() in text:
            return False

    include_kws = criteria.get("keywords_include", []) or []
    if include_kws and not any(kw.lower() in text for kw in include_kws):
        return False

    # NOTE: l'extraction de prix/surface depuis un flux RSS est
    # approximative (le texte varie selon le site). Ceci est une
    # heuristique simple à affiner selon le format réel de tes flux.
    return True


def fetch_new_listings(feeds, seen_ids, criteria):
    new_items = []
    for feed_cfg in feeds:
        if not feed_cfg.get("enabled", False):
            continue

        parsed = feedparser.parse(feed_cfg["url"])
        for entry in parsed.entries:
            entry_id = entry.get("id") or entry.get("link")
            if not entry_id or entry_id in seen_ids:
                continue

            if not matches_criteria(entry, criteria):
                continue

            new_items.append({
                "feed_name": feed_cfg["name"],
                "title": entry.get("title", "Sans titre"),
                "link": entry.get("link", ""),
                "summary": entry.get("summary", ""),
            })
            seen_ids.add(entry_id)

    return new_items


def build_email_body(items):
    if not items:
        return None

    lines = ["Voici les nouvelles annonces correspondant à tes critères du jour :\n"]
    for item in items:
        lines.append(f"— [{item['feed_name']}] {item['title']}")
        lines.append(f"  {item['link']}\n")

    return "\n".join(lines)


def main():
    config = load_config()
    seen_ids = load_seen()

    new_items = fetch_new_listings(
        config.get("feeds", []),
        seen_ids,
        config.get("criteria", {}),
    )

    body = build_email_body(new_items)

    if body:
        subject = f"{config['email']['subject_prefix']} - {len(new_items)} nouvelle(s) annonce(s)"
        send_email(
            to_addr=config["email"]["to"],
            subject=subject,
            body=body,
        )
        print(f"Email envoyé avec {len(new_items)} annonce(s).")
    else:
        print("Aucune nouvelle annonce correspondant aux critères aujourd'hui.")

    save_seen(seen_ids)


if __name__ == "__main__":
    main()
