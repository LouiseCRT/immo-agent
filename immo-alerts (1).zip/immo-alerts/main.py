#!/usr/bin/env python3
"""
immo-alerts : interroge l'API Bien'ici selon les critères de config.yaml,
et envoie un email récapitulatif des nouvelles annonces (jamais vues avant).

Usage:
    python main.py
"""

import json
import yaml
from pathlib import Path

from bienici_client import search_listings
from emailer import send_email

CONFIG_PATH = Path(__file__).parent / "config.yaml"
SEEN_PATH = Path(__file__).parent / "seen.json"


def load_config():
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def load_seen():
    if SEEN_PATH.exists():
        with open(SEEN_PATH, "r", encoding="utf-8") as f:
            return set(json.load(f))
    return set()


def save_seen(seen_ids):
    with open(SEEN_PATH, "w", encoding="utf-8") as f:
        json.dump(sorted(seen_ids), f, ensure_ascii=False, indent=2)


def passes_keyword_filter(ad, criteria):
    text = f"{ad.get('title', '')} {ad.get('description', '')}".lower()
    for kw in criteria.get("keywords_exclude", []) or []:
        if kw.lower() in text:
            return False
    return True


def build_email_body(new_ads):
    if not new_ads:
        return None

    lines = ["Voici les nouvelles annonces correspondant à tes critères du jour :\n"]
    for ad in new_ads:
        price = ad.get("price", "?")
        surface = ad.get("surfaceArea", "?")
        rooms = ad.get("roomsQuantity", "?")
        city = ad.get("city", "")
        title = ad.get("title", "Sans titre")
        ad_id = ad.get("id", "")
        link = f"https://www.bienici.com/annonce/{ad_id}" if ad_id else ""

        lines.append(f"— {title} ({city})")
        lines.append(f"  {price} € · {surface} m² · {rooms} pièce(s)")
        if link:
            lines.append(f"  {link}")
        lines.append("")

    return "\n".join(lines)


def main():
    config = load_config()
    criteria = config.get("criteria", {})
    seen_ids = load_seen()

    ads = search_listings(criteria)

    new_ads = []
    for ad in ads:
        ad_id = ad.get("id") or ad.get("reference")
        if not ad_id or ad_id in seen_ids:
            continue
        if not passes_keyword_filter(ad, criteria):
            continue
        new_ads.append(ad)
        seen_ids.add(ad_id)

    body = build_email_body(new_ads)

    if body:
        subject = f"{config['email']['subject_prefix']} - {len(new_ads)} nouvelle(s) annonce(s)"
        send_email(
            to_addr=config["email"]["to"],
            subject=subject,
            body=body,
        )
        print(f"Email envoyé avec {len(new_ads)} annonce(s).")
    else:
        print("Aucune nouvelle annonce correspondant aux critères aujourd'hui.")

    save_seen(seen_ids)


if __name__ == "__main__":
    main()
